# Bacbo-bot

Bot para enviar sinais do jogo Bac Bo para Telegram.