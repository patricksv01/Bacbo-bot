
import time

while True:
    print("Bot rodando...")
    time.sleep(10)
